#include "scheduler.h"
#include "tasks.h"
#include "timer.h"
#include "common.h"
#include "monitor.h"
#include "isr.h"

#define TIME_QUANTUM 100     // amount of time a task is allowed to run before 
                            // scheduler potentially switches to another task
#define AGING_THRESHOLD 5  // aging prevents starvation by gradually increasing
                           // the priority of task that waits in the priority queue 
                          // for too long 


// struct to represent nodes of priority queue             
typedef struct priority_queue_node {
    task_t *task;
    struct priority_queue_node *next;
} pq_node_t;

static pq_node_t *ready_queue = NULL;  // head of priority queue of tasks
static task_t *current_task = NULL;   // pointer to the currently running task
static u32int quantum_count = 0;      // counter to determine when to switch tasks   
static u32int aging_counter = 0;      // determine when to apply the aging mechanism to taks in queue 

// function to add a task to priority queue based on priority
static void enqueue_task(task_t *task) {
    pq_node_t *new_node = (pq_node_t *)kmalloc(sizeof(pq_node_t));
    new_node->task = task;
    new_node->next = NULL;

    if (ready_queue == NULL || ready_queue->task->priority > task->priority) {
        new_node->next = ready_queue;
        ready_queue = new_node;
    } else {
        pq_node_t *current = ready_queue;
        while (current->next != NULL && current->next->task->priority <= task->priority) {
            current = current->next;
        }
        new_node->next = current->next;
        current->next = new_node;
    }
    monitor_write("Enqueued task with priority: ");
    monitor_write_dec(task->priority);
    monitor_write("\n");
}

// function to add a task to the end of the ready queue
static void enqueue_task_end(task_t *task) {
    pq_node_t *new_node = (pq_node_t *)kmalloc(sizeof(pq_node_t));
    new_node->task = task;
    new_node->next = NULL;

    if (ready_queue == NULL) {
        ready_queue = new_node;
    } else {
        pq_node_t *current = ready_queue;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = new_node;
    }
    monitor_write("Re-enqueued task at end with priority: ");
    monitor_write_dec(task->priority);
    monitor_write("\n");
}

// function to remove the task at the front of the ready queue
static task_t *dequeue_task() {
    if (ready_queue == NULL) {
        return NULL;
    }
    pq_node_t *node = ready_queue;
    task_t *task = node->task;
    ready_queue = ready_queue->next;
    kfree(node);
    monitor_write("Dequeued task with priority: ");
    monitor_write_dec(task->priority);
    monitor_write("\n");
    return task;
}

// wrapper function to add a task to the scheduler by enquing it
void scheduler_add_task(task_t *task) {
    enqueue_task(task);
}

// function to yiled CPU from the current task
void scheduler_yield() {
    if (current_task != NULL) {
        // update the remaining period of the current task
        current_task->remaining_period -= TIME_QUANTUM;
        monitor_write("Task with ID: ");
        monitor_write_dec(current_task->task_id);
        monitor_write(", priority: ");
        monitor_write_dec(current_task->priority);
        monitor_write(", remaining period: ");
        monitor_write_dec(current_task->remaining_period);
        monitor_write("\n");

        // If the task has not finished its period, reset its priority to the original
        current_task->priority = current_task->original_priority;

        // re-enqueue the task if its remaining period is not exhausted
        if (current_task->remaining_period > 0) {
            enqueue_task(current_task);
        } else {
            // reset the task's remaining period to its original period
            current_task->remaining_period = current_task->period;
            enqueue_task_end(current_task);
            monitor_write("Task with ID: ");
            monitor_write_dec(current_task->task_id);
            monitor_write(" has finished its period and is reset.\n");
        }
    }

    // aging: increase the priority of tasks that have been waiting
    if (++aging_counter >= AGING_THRESHOLD) {
        pq_node_t *current = ready_queue;
        while (current != NULL) {
            if (current->task->priority > 1) {
                current->task->priority--;
            }
            current = current->next;
        }
        aging_counter = 0;
    }

    current_task = dequeue_task();
    quantum_count = 0;  // reset the quantum count for the new task
    if (current_task != NULL) {
        monitor_write("Switching to task with ID: ");
        monitor_write_dec(current_task->task_id);
        monitor_write(", priority: ");
        monitor_write_dec(current_task->priority);
        monitor_write("\n");
    }
    // adding delay to make task switching observable
    for (volatile int i = 0; i < 999999999; i++);
}

void scheduler_schedule() {
    quantum_count++;
    if (quantum_count >= TIME_QUANTUM) {
        scheduler_yield();
    }
    if (current_task != NULL) {
        current_task->function(current_task->arg);
    }
}

// function to initialize the scheduler
void scheduler_init() {
    quantum_count = 0;
    aging_counter = 0;
    current_task = NULL;
}

// function as a callback for the timer interrupt
// that schedules the next task whenever the timer
// interrupt occurs
static void timer_callback(registers_t regs) {
    scheduler_schedule();
}

// function to setup the scheduler timer by registering
// timer interrupt handles and initializing timer
void init_scheduler_timer() {
  register_interrupt_handler(IRQ0, &timer_callback);
  init_timer(100);  // Initialize the timer with frequency 100 Hz (10 ms time quantum)
}