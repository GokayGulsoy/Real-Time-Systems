#ifndef TASKS_H
#define TASKS_H

#include "common.h"

typedef struct task {
    void (*function)(void *);
    void *arg;
    u32int stack_size;
    u32int period;
    u32int remaining_period; 
    u32int priority;
    u32int original_priority;
    int task_id; 
    u32int *stack;   // stack pointer for the task
    struct task *next;
} task_t;

void task_create(task_t *task, void (*function)(void *), void *arg);

#endif
