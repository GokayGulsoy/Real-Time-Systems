#include "monitor.h"
#include "descriptor_tables.h"
#include "timer.h"
#include "shell.h"
#include "kb.h"
#include "isr.h"
#include "tasks.h"
#include "scheduler.h"
#include "common.h"

// delay function to make task execution more apparent
void delay() {
    for (volatile int i = 0; i < 1000000; i++);
}

// Task function
void Task(void *arg) {
    task_t *task = (task_t *)arg; 
    while (1) {
        delay();  // adding delay to simulate task work
        scheduler_yield(); 
    }
}

// function to start the scheduler simulation
void start_scheduler_simulation() {
    // initialize scheduler
    scheduler_init();

    // create task1
    task_t t1;
    t1.stack_size = 256;
    t1.period = 500;  // 500 ms
    t1.priority = 1; // highest priority
    monitor_write("Creating Task1...\n");
    task_create(&t1, Task, &t1);

    // create task2
    task_t t2;
    t2.stack_size = 256;
    t2.period = 800;  // 800 ms
    t2.priority = 2; // medium priority
    monitor_write("Creating Task2...\n");
    task_create(&t2, Task, &t2);

    // create task 3
    task_t t3;
    t3.stack_size = 256;
    t3.period = 700;  // 700 ms
    t3.priority = 3; // lowest priority
    monitor_write("Creating Task3...\n");
    task_create(&t3, Task, &t3);

    // start the scheduler
    monitor_write("Starting the scheduler...\n");
    while (1) {
        scheduler_schedule();
    }
}

int main(struct multiboot *mboot_ptr) {
    // initialize all the ISRs and segmentation
    init_descriptor_tables();

    // initializing the screen (by clearing it)
    monitor_clear();

    // initializing the keyboard
    keyboard_install();

    // writing welcoming message to the screen
    monitor_write_color("Welcome to OSX383\n\n", VGA_COLOR_LIGHT_GREEN, VGA_COLOR_BLACK);

    // initializing the scheduler timer
    init_scheduler_timer();

    // enabling interrupts
    asm volatile("sti");

    // start the shell
    shell();

    return 0;
}
