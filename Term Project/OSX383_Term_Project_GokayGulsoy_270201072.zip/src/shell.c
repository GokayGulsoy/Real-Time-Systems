#include "common.h"
#include "monitor.h"
#include "rtc.h"
#include "scheduler.h"

// declare external cursor position variables
extern u16int cursor_x;
extern u16int cursor_y;

extern void start_scheduler_simulation();

void shell() {
    char command[128];
    monitor_write_color("OSx383> ", VGA_COLOR_CYAN, VGA_COLOR_BLACK);

    while (1) {
        monitor_set_cursor(7, cursor_y); // ensure cursor is next to the shell prompt
        gets(command);

        monitor_put_color('\n', VGA_COLOR_WHITE | (VGA_COLOR_BLACK << 4));

        if (strcmp(command, "help") == 0) {
            monitor_write_color("Available commands: help, settime, reboot, simulate scheduler\n\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
        } else if (strncmp(command, "settime", 7) == 0) {
            u8int hour = 0, minute = 0, second = 0;
            int i = 7, result = 0;
            int values[3] = {0, 0, 0}; // array to hold hour, minute, second
            int valueIndex = 0;
            int currentValue = 0;

            // skip initial spaces after "settime"
            while (command[i] == ' ') {
                i++;
            }

            // parse the settime command string
            while (command[i] != '\0') {
                if (command[i] >= '0' && command[i] <= '9') {
                    currentValue = currentValue * 10 + (command[i] - '0');
                } else if (command[i] == ' ' || command[i + 1] == '\0') {
                    if (command[i + 1] == '\0' && command[i] >= '0' && command[i] <= '9') {
                        currentValue = currentValue * 10 + (command[i] - '0');
                    }
                    if (valueIndex < 3) {
                        values[valueIndex++] = currentValue;
                        currentValue = 0;
                    }
                    if (command[i] == ' ') {
                        // skip any additional spaces between numbers
                        while (command[i] == ' ') {
                            i++;
                        }
                        i--; // adjust for the outer increment
                    }
                } else {
                    result = -1; // invalid character found
                    break;
                }
                // check in order not to require one more space at the end of the string
                if (command[i + 1] == '\0' && valueIndex < 3) {
                    values[valueIndex++] = currentValue;
                    currentValue = 0;
                    break;
                }
                i++;
            }

            if (valueIndex == 3 && result == 0) {
                hour = values[0];
                minute = values[1];
                second = values[2];

                // validate time values
                if (hour > 23 || minute > 59 || second > 59) {
                    monitor_write_color("Invalid time. Please use the format hh (0-23), mm (0-59), ss (0-59).\n\n", VGA_COLOR_RED, VGA_COLOR_BLACK);
                } else {
                    // Set the RTC time
                    time_t new_time;
                    new_time.hours = hour;
                    new_time.minutes = minute;
                    new_time.seconds = second;
                    write_rtc(&new_time);

                    // display the time that has been set
                    monitor_write_color("Time has been set to ", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    if (hour < 10)
                        monitor_write_color("0", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    monitor_write_dec_color(hour, VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    monitor_write_color(":", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    if (minute < 10)
                        monitor_write_color("0", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    monitor_write_dec_color(minute, VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    monitor_write_color(":", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    if (second < 10)
                        monitor_write_color("0", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    monitor_write_dec_color(second, VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                    monitor_write_color("\n\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                }
            } else {
                monitor_write_color("Usage: settime hh mm ss\n\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
            }
        } else if (strcmp(command, "reboot") == 0) {
            monitor_write_color("\nRebooting in 5 seconds...\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
            for (int j = 5; j > 0; j--) {
                monitor_write_dec_color(j, VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                monitor_write_color(" seconds remaining...\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
                for (int k = 0; k < 1000000000; k++)
                    ; // crude delay loop
            }
            // use the keyboard controller to pulse the CPU reset line
            asm volatile("cli"); // disable interrupts
            asm volatile("outb %%al, $0x64" : : "a"(0xFE));
            while (1) {
                asm volatile("hlt");
            } // halt the CPU
        } else if (strcmp(command, "simulate scheduler") == 0) {
            monitor_write_color("Starting scheduler simulation...\n\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
            start_scheduler_simulation();
        } else {
            monitor_write_color("Invalid command. Type 'help' for a list of available commands\n\n", VGA_COLOR_WHITE, VGA_COLOR_BLACK);
        }

        monitor_write_color("OSx383> ", VGA_COLOR_CYAN, VGA_COLOR_BLACK);
    }
}
