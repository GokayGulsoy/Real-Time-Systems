#include "common.h"
#include "rtc.h"

// function to read data from
// specified CMOS register
u8int read_cmos(u8int reg)
{
    outb(CMOS_ADDRESS, reg); // writing register number to read from port 0x70
    return inb(CMOS_DATA);  // reading data from chosen register according to 
                            // specified register number `reg`
}

// function to check whether RTC update
// is still in progress or not 
u8int get_update_in_progress_flag()
{
    outb(CMOS_ADDRESS, 0x0A); // register 0x0A contains the update-in-progress flag
    return inb(CMOS_DATA) & 0x80; // masking with 0x80 to check update in progress bit
}

// function that converts binary-coded decimal (BCD)
// value to regular decimal value 
u8int from_bcd(u8int value)
{
    return (value & 0x0F) + ((value / 16) * 10);
}

// funtion that converts a regular decimal value 
// to binary-coded decimal (BCD) value 
u8int to_bcd(u8int value)
{
    return ((value / 10) << 4) | (value % 10);
}

// function to read the current time from the RTC
void read_rtc(time_t *time)
{
    while (get_update_in_progress_flag())
    {
        // wait until update is completed
    }

    // Read RTC registers twice to ensure consistency
    u8int last_seconds, last_minutes, last_hours;
    u8int seconds, minutes, hours;
    do {
        last_seconds = seconds;
        last_minutes = minutes;
        last_hours = hours;

        while (get_update_in_progress_flag()) {
            // wait until update is completed
        }

        seconds = read_cmos(0x00); // 0x00 register contains the seconds
        minutes = read_cmos(0x02); // 0x02 register contains the minutes
        hours = read_cmos(0x04);   // 0x04 register contains the hours
    } while (last_seconds != seconds || last_minutes != minutes || last_hours != hours);

    // store the read values
    time->seconds = seconds;
    time->minutes = minutes;
    time->hours = hours;

    // converting BCD to binary if 2nd bit 
    // of the register 0x0B is not set
    u8int regB = read_cmos(0x0B);

    if (!(regB & 0x04))
    {
        time->seconds = from_bcd(time->seconds);
        time->minutes = from_bcd(time->minutes);
        time->hours = from_bcd(time->hours);

        // converting 12 hour clock to 24 hour clock
        if (!(regB & 0x02) && (time->hours & 0x80))
        {
            // if register B's bit 1 is 0, time is in 12-hour format
            // and also check if MSB is 1 which indicates PM
            time->hours = ((time->hours & 0x7F) + 12) % 24;
        }
    }
}

// function writes the provided time to RTC registers
void write_rtc(time_t *time)
{
    while (get_update_in_progress_flag())
    {
        // wait until update is completed
    }

    // convert to BCD if necessary
    u8int regB = read_cmos(0x0B);

    u8int seconds = time->seconds;
    u8int minutes = time->minutes;
    u8int hours = time->hours;

    if (!(regB & 0x04))
    {
        seconds = to_bcd(seconds);
        minutes = to_bcd(minutes);
        hours = to_bcd(hours);

        // converting 24 hour clock to 12 hour clock if necessary
        if (!(regB & 0x02) && (hours > 12))
        {
            hours = (hours % 12) | 0x80; // set PM flag
        }
    }

    // write values to RTC registers
    outb(CMOS_ADDRESS, 0x00); // select seconds register
    outb(CMOS_DATA, seconds);
    outb(CMOS_ADDRESS, 0x02); // select minutes register
    outb(CMOS_DATA, minutes);
    outb(CMOS_ADDRESS, 0x04); // select hours register
    outb(CMOS_DATA, hours);
}
