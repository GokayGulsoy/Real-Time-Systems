#ifndef KB_H
#define KB_H

// function prototypes
void keyboard_install(); 
char getchar();

#endif