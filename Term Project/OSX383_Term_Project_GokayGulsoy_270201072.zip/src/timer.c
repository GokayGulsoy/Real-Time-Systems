#include "timer.h"
#include "isr.h"
#include "monitor.h"
#include "rtc.h"

u32int tick = 0;

// Save the current cursor position
extern u16int cursor_x;
extern u16int cursor_y;

// function to display the clock 
// on the top right of the shell 
static void timer_callback(registers_t regs)
{
    tick++;
    if (tick % 18 == 0)
    { // update approximately every second
        time_t current_time;
        read_rtc(&current_time);

        // validate current time values before updating
        if (current_time.hours > 23 || current_time.minutes > 59 || current_time.seconds > 59)
        {
            monitor_write_color("Invalid time detected. Keeping previous valid time.\n", VGA_COLOR_RED, VGA_COLOR_BLACK);
        }
        else
        {
            // wrap the time correctly
            current_time.seconds++;
            if (current_time.seconds > 59)
            {
                current_time.seconds = 0;
                current_time.minutes++;
            }
            if (current_time.minutes > 59)
            {
                current_time.minutes = 0;
                current_time.hours++;
            }
            if (current_time.hours > 23)
            {
                current_time.hours = 0;
            }
        }

        // save the current cursor position
        u8int saved_cursor_x = cursor_x;
        u8int saved_cursor_y = cursor_y;

        // calculate the position for displaying the time to ensure it stays on one line
        u8int cursor_start_x = 66;
        u8int cursor_start_y = 0;

        // clear the area where the time will be displayed
        monitor_set_cursor(cursor_start_x, cursor_start_y);
        for (int i = 0; i < 12; i++)
        { // "Time: hh:mm:ss" has a length of 12 characters
            monitor_put_color(' ', VGA_COLOR_YELLOW | (VGA_COLOR_LIGHT_GREY << 4));
        }

        // reset the cursor position
        monitor_set_cursor(cursor_start_x, cursor_start_y);

        // display the time directly
        monitor_write_color("Time: ", VGA_COLOR_YELLOW, VGA_COLOR_LIGHT_GREY);
        if (current_time.hours < 10)
            monitor_put_color('0', VGA_COLOR_YELLOW | (VGA_COLOR_LIGHT_GREY << 4));
        monitor_write_dec_color(current_time.hours, VGA_COLOR_YELLOW, VGA_COLOR_LIGHT_GREY);
        monitor_put_color(':', VGA_COLOR_YELLOW | (VGA_COLOR_LIGHT_GREY << 4));
        if (current_time.minutes < 10)
            monitor_put_color('0', VGA_COLOR_YELLOW | (VGA_COLOR_LIGHT_GREY << 4));
        monitor_write_dec_color(current_time.minutes, VGA_COLOR_YELLOW, VGA_COLOR_LIGHT_GREY);
        monitor_put_color(':', VGA_COLOR_YELLOW | (VGA_COLOR_LIGHT_GREY << 4));
        if (current_time.seconds < 10)
            monitor_put_color('0', VGA_COLOR_YELLOW | (VGA_COLOR_LIGHT_GREY << 4));
        monitor_write_dec_color(current_time.seconds, VGA_COLOR_YELLOW, VGA_COLOR_LIGHT_GREY);

        // restore the cursor position
        monitor_set_cursor(saved_cursor_x, saved_cursor_y);
    }
}

// function to configure Programmable Interval Timer (PIT)
// to generate interrupts at a specified frequency
void init_timer(u32int frequency)
{
    register_interrupt_handler(IRQ0, &timer_callback);

    u32int divisor = 1193180 / frequency;
    outb(0x43, 0x36);

    // as data port of PIT (Programmable Interval Timer) is capable
    // of handling 8 bit data at a time we split divisor into low
    // byte `l` and high byte `h` 
    u8int l = (u8int)(divisor & 0xFF);
    u8int h = (u8int)((divisor >> 8) & 0xFF);

    outb(0x40, l);
    outb(0x40, h);
}

void set_timer_periodic(unsigned int period) {
    u32int frequency = 1000000 / period;
    init_timer(frequency);
}

void wait_timer_event() {
    asm volatile ("hlt");
    scheduler_yield();
}
