#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "tasks.h"

void scheduler_add_task(task_t *task);
void scheduler_yield(void);
void scheduler_schedule(void);
void scheduler_init(void);

#endif