#ifndef STDDEF_H
#define STDDEF_H

typedef unsigned int size_t;

#endif