#include "tasks.h"
#include "common.h"
#include "scheduler.h"

static u32int next_task_id = 1; // assign a unique id to each new task created

void task_create(task_t *task, void (*function)(void *), void *arg) {
    task->function = function;                            // task's function pointer
    task->arg = arg;                                     // task's argument
    task->task_id = next_task_id++;                     // id of the task
    task->stack = (u32int *)kmalloc(task->stack_size);  // stack size for task
    task->remaining_period = task->period;             // remaining period
    task->original_priority = task->priority;          // original  priority
    scheduler_add_task(task);
}
