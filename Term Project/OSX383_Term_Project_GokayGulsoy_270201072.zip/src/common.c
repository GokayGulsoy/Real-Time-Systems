#include "common.h"
#include "monitor.h"
#include "kb.h"

extern u16int cursor_x;
extern u16int cursor_y;

#define HEAP_SIZE 1024 * 1024 // 1MB heap size

static unsigned char heap[HEAP_SIZE];
static unsigned int heap_index = 0;

typedef struct free_block { 
    unsigned int size;
    struct free_block *next;
} free_block_t;

static free_block_t *free_list = NULL;

// write byte to port
void outb(u16int port, u8int value)
{
    asm volatile ("outb %1, %0" : : "dN" (port), "a" (value));
}

// read byte from port
u8int inb(u16int port)
{
    u8int ret;
    asm volatile("inb %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

// read word from port
u16int inw(u16int port)
{
    u16int ret;
    asm volatile ("inw %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

// copy len bytes from src to dest
void memcpy(u8int *dest, const u8int *src, u32int len)
{
    const u8int *sp = (const u8int *)src;
    u8int *dp = (u8int *)dest;
    for(; len != 0; len--) *dp++ = *sp++;
}

// fill dest to dest+len with val
void memset(u8int *dest, u8int val, u32int len)
{
    u8int *temp = (u8int *)dest;
    for ( ; len != 0; len--) *temp++ = val;
}

// compare two strings
int strcmp(char *str1, char *str2)
{
    int i = 0;
    while (str1[i] != '\0' && str2[i] != '\0') {
        if (str1[i] != str2[i]) {
            return str1[i] - str2[i];
        }
        i++;
    }
    return str1[i] - str2[i];
}

// calculate the length of a string
size_t strlen(const char *str)
{
    size_t len = 0;
    while (str[len] != '\0')
    {
        len++;
    }
    return len;
}

// copy src to dest
char *strcpy(char *dest, const char *src)
{
    char *temp = dest;
    while ((*dest++ = *src++) != '\0');
    return temp;
}

// concatenate dest with src
char *strcat(char *dest, const char *src)
{
    char *temp = dest;
    while (*dest) {
        dest++;
    }
    while ((*dest++ = *src++) != '\0');
    return temp;
}

// read a line from the input
char *gets(char *buffer)
{
    char *buf_ptr = buffer;
    char c;
    while ((c = getchar()) != '\n')
    {
        if (c == '\b' && buf_ptr > buffer)
        {
            monitor_put(c);
            buf_ptr--;
        }
        else
        {
            monitor_put(c);
            *buf_ptr++ = c;
        }
    }
    *buf_ptr = '\0';
    return buffer;
}

// compare first n bytes of str1 and str2
int strncmp(const char *str1, const char *str2, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        if (str1[i] != str2[i] || str1[i] == '\0')
        {
            return str1[i] - str2[i];
        }
    }
    return 0;
}

// helper function to convert integer to string (itoa)
void itoa(int value, char *str, int base)
{
    char *rc = str;
    char *ptr;
    char *low;
    // Check for supported base.
    if (base < 2 || base > 36)
    {
        *str = '\0';
        return;
    }

    // handle negative integers for base 10
    int is_negative = 0;
    if (value < 0 && base == 10)
    {
        is_negative = 1;
        value = -value;
    }

    ptr = str;

    // The actual conversion
    do
    {
        int digit = value % base;
        *ptr++ = (digit > 9) ? (digit - 10) + 'a' : digit + '0';
    } while (value /= base);

    // add negative sign if necessary
    if (is_negative)
    {
        *ptr++ = '-';
    }

    // null-terminate the string
    *ptr-- = '\0';

    // reverse the string
    while (rc < ptr)
    {
        char tmp = *rc;
        *rc++ = *ptr;
        *ptr-- = tmp;
    }
}

// write a string at a specific position on the monitor
void monitor_write_position(const char* str, u8int fore_color, u8int back_color, u8int x, u8int y) {
    // save the current cursor position
    u16int saved_cursor_x = cursor_x;
    u16int saved_cursor_y = cursor_y;
    
    // move to the target position
    monitor_set_cursor(x, y);

    // Write the string
    while (*str) {
        monitor_put_color(*str++, fore_color | (back_color << 4));
    }

    // restore the cursor position
    monitor_set_cursor(saved_cursor_x, saved_cursor_y);
}

// function for allocating heap memory
void *kmalloc(unsigned int size) {
    // align size to 8 bytes
    size = (size + 7) & ~7;

    // search free list for suitable block
    free_block_t **current = &free_list;
    while ((*current)) {
        if ((*current)->size >= size) {
            void *ptr = *current;
            *current = (*current)->next;
            return ptr;
        }

        current = &(*current)->next;
    }

    // allocate from heap if no suitable free block is found
    if (heap_index + size > HEAP_SIZE) {
        return NULL; // out of memory
    }

    void *ptr = &heap[heap_index];
    heap_index += size;
    return ptr;
}

// function for freeing heap memory
void kfree(void *ptr) {
    // add the block to freelist
    free_block_t *block = (free_block_t *)ptr;
    block->size = 0; 
    block->next = free_list;
    free_list = block;
}
