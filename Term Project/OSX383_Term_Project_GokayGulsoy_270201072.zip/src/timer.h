#ifndef TIMER_H
#define TIMER_H

#include "common.h"

void init_timer(u32int);
void set_timer_periodic(unsigned int period);
void wait_timer_event();

#endif
