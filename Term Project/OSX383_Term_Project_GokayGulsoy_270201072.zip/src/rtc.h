#ifndef RTC_H
#define RTC_H

# include "common.h"

#define CMOS_ADDRESS 0X70  // CMOS port address to write register number for reading
#define CMOS_DATA 0x71     // CMOS port address to read data from specified register

// time_t struct to represent RTC time
typedef struct {
    u8int seconds;
    u8int minutes;
    u8int hours;
} time_t; 

// function prototypes
void read_rtc(time_t *);
void set_rtc_time(u8int , u8int, u8int);
void write_rtc(time_t *);
u8int get_update_in_progress_flag();
u8int from_bcd(u8int);

#endif