#include "monitor.h"
#include "descriptor_tables.h"
#include "timer.h"
#include "isr.h"

/*
static void isr3_callback(registers_t regs)
{
    monitor_write("This is interrupt service routine 3 \n");

}*/

int main(struct multiboot *mboot_ptr)
{
    init_descriptor_tables();
    monitor_clear();
    monitor_write("Welcome to OSx311 Kernel.\n");
    monitor_write("OK\n");
    
    //register_interrupt_handler(3, &isr3_callback);

    asm volatile("int $0x3");
    //asm volatile("int $0x4");


    asm volatile("sti");
    init_timer(50);

    return 0xDEADBABA;
}
